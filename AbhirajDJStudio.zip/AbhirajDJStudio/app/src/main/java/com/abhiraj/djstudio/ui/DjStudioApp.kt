package com.abhiraj.djstudio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.abhiraj.djstudio.ui.screens.AiScreen
import com.abhiraj.djstudio.ui.screens.BeatMakerScreen
import com.abhiraj.djstudio.ui.screens.DrumPadsScreen
import com.abhiraj.djstudio.ui.screens.FxStudioScreen
import com.abhiraj.djstudio.ui.screens.LibraryScreen
import com.abhiraj.djstudio.ui.screens.MixerScreen
import com.abhiraj.djstudio.ui.screens.SettingsScreen
import com.abhiraj.djstudio.ui.theme.DjColors

enum class Overlay { NONE, LIBRARY, AI, SETTINGS }

/**
 * Mixer (centre) --swipe left--> Drum Pads, --swipe right--> FX Studio, --swipe up--> Beat Maker.
 * LIB / AI / gear open full-screen overlays on top.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DjStudioApp() {
    var overlay by remember { mutableStateOf(Overlay.NONE) }
    val vertical = rememberPagerState(initialPage = 0) { 2 }
    BackHandler(enabled = overlay != Overlay.NONE) { overlay = Overlay.NONE }

    Box(Modifier.fillMaxSize().background(DjColors.Bg)) {
        VerticalPager(state = vertical, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 0) MixerRow { overlay = it } else BeatMakerScreen()
        }
        when (overlay) {
            Overlay.LIBRARY -> LibraryScreen { overlay = Overlay.NONE }
            Overlay.AI -> AiScreen({ overlay = Overlay.NONE }) { overlay = it }
            Overlay.SETTINGS -> SettingsScreen { overlay = Overlay.NONE }
            Overlay.NONE -> {}
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MixerRow(onOpen: (Overlay) -> Unit) {
    // pages: 0 = FX Studio, 1 = Mixer, 2 = Drum Pads
    val horizontal = rememberPagerState(initialPage = 1) { 3 }
    HorizontalPager(state = horizontal, modifier = Modifier.fillMaxSize()) { page ->
        when (page) {
            0 -> FxStudioScreen()
            1 -> MixerScreen(onOpen)
            else -> DrumPadsScreen()
        }
    }
}
