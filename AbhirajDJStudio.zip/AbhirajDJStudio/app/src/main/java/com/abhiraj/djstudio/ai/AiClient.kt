package com.abhiraj.djstudio.ai

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class AiException(message: String) : Exception(message)
data class ModelInfo(val id: String, val free: Boolean)
data class AiResult(val text: String, val usedModel: String, val note: String?)
private class HttpRes(val code: Int, val body: String, val rate: String)

/** Plain HttpURLConnection client. Blocking: call from Dispatchers.IO. Never logs keys. */
object AiClient {
    var lastRate by mutableStateOf("")

    private fun base(p: Provider): String {
        val b = if (p == Provider.CUSTOM) AiSettings.customBase.trim().trimEnd('/') else p.baseUrl
        if (b.isBlank()) throw AiException("Set the endpoint URL in Settings first.")
        return b
    }

    private fun headers(p: Provider): Map<String, String> {
        val h = HashMap<String, String>()
        h["Content-Type"] = "application/json"
        val k = AiSettings.key()
        if (p == Provider.GEMINI) { if (k.isNotBlank()) h["x-goog-api-key"] = k }
        else if (k.isNotBlank()) h["Authorization"] = "Bearer $k"
        return h
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): HttpRes {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = method
                c.connectTimeout = 15000
                c.readTimeout = 60000
                for ((k, v) in headers) c.setRequestProperty(k, v)
                if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val rate = c.headerFields
                    .filterKeys { k -> k != null && (k.lowercase().contains("ratelimit") || k.lowercase() == "retry-after") }
                    .entries.joinToString("; ") { "${it.key}: ${it.value.joinToString()}" }
                if (rate.isNotBlank()) lastRate = rate
                return HttpRes(code, text, rate)
            } finally { c.disconnect() }
        } catch (e: IOException) {
            throw AiException("Network error: ${e.message}")
        }
    }

    private fun describe(r: HttpRes): String {
        val apiMsg = try { JSONObject(r.body).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
        val head = when (r.code) {
            401, 403 -> "Key rejected or no access (${r.code})"
            429 -> "Rate limit reached (429). Wait a bit or pick another model."
            404 -> "Model or endpoint not found (404)"
            else -> "HTTP ${r.code}"
        }
        return head + (if (!apiMsg.isNullOrBlank()) ": " + apiMsg.take(200) else "") +
            (if (r.rate.isNotBlank()) "\n" + r.rate else "")
    }

    fun listModels(): List<ModelInfo> {
        val p = AiSettings.provider
        val url = if (p == Provider.GEMINI) base(p) + "/models?pageSize=200" else base(p) + "/models"
        val res = http("GET", url, headers(p), null)
        if (res.code !in 200..299) throw AiException(describe(res))
        val j = JSONObject(res.body)
        val out = ArrayList<ModelInfo>()
        if (p == Provider.GEMINI) {
            val arr = j.optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val m = o.optJSONArray("supportedGenerationMethods")
                var ok = m == null
                if (m != null) for (k in 0 until m.length()) if (m.getString(k) == "generateContent") ok = true
                if (ok) out.add(ModelInfo(o.getString("name").removePrefix("models/"), false))
            }
        } else {
            val arr = j.optJSONArray("data") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val pr = o.optJSONObject("pricing")
                val free = id.endsWith(":free") || (pr != null && pr.optString("prompt") == "0" && pr.optString("completion") == "0")
                out.add(ModelInfo(id, free))
            }
        }
        return out
    }

    fun chat(system: String, user: String, modelRaw: String): String {
        val p = AiSettings.provider
        val model = modelRaw.trim().removePrefix("models/")
        if (model.isBlank()) throw AiException("No model selected. Open Settings and choose one.")
        if (p == Provider.GEMINI) {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                .toString()
            val res = http("POST", base(p) + "/models/" + model + ":generateContent", headers(p), body)
            if (res.code !in 200..299) throw AiException(describe(res))
            val parts = JSONObject(res.body).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw AiException("Empty response (blocked or no output)")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString()
        } else {
            val body = JSONObject().put("model", model).put("temperature", 0.7)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
                .toString()
            val res = http("POST", base(p) + "/chat/completions", headers(p), body)
            if (res.code !in 200..299) throw AiException(describe(res))
            return JSONObject(res.body).optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")
                ?: throw AiException("Empty response")
        }
    }

    /** Primary model, then ONLY the fallback model the user chose. Never switches on its own. */
    fun chatWithFallback(system: String, user: String): AiResult {
        val primary = AiSettings.model()
        val fb = AiSettings.fallback()
        try {
            return AiResult(chat(system, user, primary), primary, null)
        } catch (e: AiException) {
            if (fb.isBlank() || fb == primary) throw e
            val t = chat(system, user, fb)
            val why = e.message?.lineSequence()?.firstOrNull() ?: "error"
            return AiResult(t, fb, "Primary model failed ($why). Used your fallback: $fb")
        }
    }
}
