package com.abhiraj.djstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.ai.AiChat
import com.abhiraj.djstudio.ai.AiClient
import com.abhiraj.djstudio.ai.AiPrompt
import com.abhiraj.djstudio.ai.AiSettings
import com.abhiraj.djstudio.ai.ChatMsg
import com.abhiraj.djstudio.ui.Overlay
import com.abhiraj.djstudio.ui.components.DjField
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.OverlayHeader
import com.abhiraj.djstudio.ui.theme.DjColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AiScreen(onBack: () -> Unit, onOpen: (Overlay) -> Unit) {
    val msgs = AiChat.msgs
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    fun doSend(text: String) {
        msgs.add(ChatMsg(true, text))
        input = ""
        busy = true
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) { AiClient.chatWithFallback(AiPrompt.system, AiPrompt.userMessage(text)) }
                val parsed = AiPrompt.parseReply(r.text)
                val note = if (r.note != null) "\n\n(${r.note})" else ""
                msgs.add(ChatMsg(false, parsed.text + note, parsed.actions, parsed.ignored))
            } catch (e: Exception) {
                msgs.add(ChatMsg(false, "⚠ " + (e.message ?: "Request failed")))
            } finally { busy = false }
        }
    }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        if (AiSettings.keyRequired && !AiSettings.hasKey) {
            msgs.add(ChatMsg(false, "Add an API key first: tap ⚙ below.")); return
        }
        if (!AiSettings.privacyAccepted) { pending = t; showPrivacy = true; return }
        doSend(t)
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text("Before you send") },
            text = {
                Text(
                    "Your message and the current mixer settings (tempo, BPM, EQ) go to " +
                        AiSettings.provider.label + " over the internet. No audio is sent. " +
                        "Track names are sent only if you turn that on in Settings. " +
                        "The provider's own privacy terms apply. Free tiers may log prompts."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    AiSettings.privacyAccepted = true; AiSettings.save(); showPrivacy = false; doSend(pending)
                }) { Text("OK, send") }
            },
            dismissButton = { TextButton(onClick = { showPrivacy = false }) { Text("Cancel") } }
        )
    }

    Column(
        Modifier.fillMaxSize().background(DjColors.Bg).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OverlayHeader("AI DJ ASSISTANT", onBack)
        Text(
            AiSettings.provider.label + " · " + (AiSettings.model().ifEmpty { "no model chosen" }) +
                (if (AiClient.lastRate.isNotEmpty()) "\n" + AiClient.lastRate else ""),
            color = DjColors.TextDim, fontSize = 10.sp
        )
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item {
                Text(
                    "Ask for BPM ideas, EQ/FX settings, drum patterns, remix ideas, or how a control works. " +
                        "The AI can only PROPOSE app changes; nothing happens until you tap APPLY.",
                    color = DjColors.TextDim, fontSize = 12.sp
                )
            }
            items(msgs) { m -> Bubble(m) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NeonButton("Bass-heavy EQ", DjColors.Purple, Modifier.weight(1f), h = 28.dp) { input = "Suggest EQ and FX for a bass-heavy track on Deck A" }
            NeonButton("House beat", DjColors.Purple, Modifier.weight(1f), h = 28.dp) { input = "Make a simple house beat for the beat maker" }
            NeonButton("Sync help", DjColors.Purple, Modifier.weight(1f), h = 28.dp) { input = "How do I beat-match two decks here?" }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { DjField(input, { input = it }, "Ask the DJ assistant…") }
            NeonButton("⚙", DjColors.Purple, Modifier.width(40.dp)) { onOpen(Overlay.SETTINGS) }
            NeonButton(if (busy) "…" else "SEND", DjColors.Magenta, Modifier.width(60.dp), active = busy) { send() }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val shape = RoundedCornerShape(12.dp)
    val c = if (m.fromUser) DjColors.Cyan else DjColors.Magenta
    Column(
        Modifier.fillMaxWidth().background(DjColors.Panel, shape).border(1.dp, c.copy(alpha = 0.5f), shape).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(if (m.fromUser) "YOU" else "AI", color = c, fontSize = 9.sp)
        Text(m.text, color = Color.White, fontSize = 12.sp)
        if (m.actions.isNotEmpty()) {
            for (a in m.actions) Text("• " + a.label, color = DjColors.TextDim, fontSize = 10.sp)
            NeonButton(if (m.applied) "APPLIED ✔" else "APPLY ${m.actions.size} CHANGE(S)", c, Modifier.fillMaxWidth(), active = m.applied) {
                if (!m.applied) { m.actions.forEach { it.run() }; m.applied = true }
            }
        }
        if (m.ignored > 0) Text("${m.ignored} unsupported action(s) ignored", color = DjColors.TextDim, fontSize = 9.sp)
    }
}
