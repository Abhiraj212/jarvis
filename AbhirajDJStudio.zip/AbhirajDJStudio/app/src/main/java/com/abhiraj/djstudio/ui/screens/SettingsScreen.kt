package com.abhiraj.djstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.ai.AiClient
import com.abhiraj.djstudio.ai.AiSettings
import com.abhiraj.djstudio.ai.ModelInfo
import com.abhiraj.djstudio.ai.Provider
import com.abhiraj.djstudio.ui.components.DjField
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.OverlayHeader
import com.abhiraj.djstudio.ui.theme.DjColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var keyInput by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var fetched by remember { mutableStateOf<List<ModelInfo>>(emptyList()) }
    var target by remember { mutableIntStateOf(0) }   // 0 = model, 1 = fallback
    var busy by remember { mutableStateOf(false) }
    val p = AiSettings.provider

    fun run(label: String, block: suspend () -> String) {
        if (busy) return
        busy = true; status = label
        scope.launch {
            status = try { withContext(Dispatchers.IO) { block() } } catch (e: Exception) { "⚠ " + (e.message ?: "failed") }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().background(DjColors.Bg).statusBarsPadding().navigationBarsPadding().imePadding()
            .padding(12.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OverlayHeader("AI SETTINGS", onBack)
        Text("PROVIDER", color = DjColors.TextDim, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (pr in Provider.values()) {
                NeonButton(pr.label, DjColors.Cyan, Modifier.weight(1f), active = pr == p) {
                    AiSettings.provider = pr; AiSettings.save(); AiSettings.refreshKey(); fetched = emptyList(); status = ""
                }
            }
        }
        if (p == Provider.CUSTOM) {
            Text("ENDPOINT (OpenAI-compatible, https only), e.g. https://host/v1", color = DjColors.TextDim, fontSize = 10.sp)
            DjField(AiSettings.customBase, { AiSettings.customBase = it; AiSettings.save() }, "https://…/v1")
        }

        Text("API KEY  ·  " + (if (AiSettings.hasKey) "saved (encrypted on this phone)" else if (AiSettings.keyRequired) "not set" else "optional"),
            color = DjColors.TextDim, fontSize = 10.sp)
        DjField(keyInput, { keyInput = it }, "Paste key here", password = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonButton("SAVE KEY", DjColors.Cyan, Modifier.weight(1f)) {
                if (keyInput.isNotBlank()) { AiSettings.setKey(keyInput); keyInput = ""; status = "Key saved" }
            }
            NeonButton("REMOVE KEY", DjColors.Magenta, Modifier.weight(1f)) { AiSettings.removeKey(); status = "Key removed" }
        }

        Text("MODEL", color = DjColors.TextDim, fontSize = 10.sp)
        DjField(AiSettings.model(), { AiSettings.models[p.name] = it; AiSettings.save() }, "Fetch the list below or type a model id")
        Text("FALLBACK MODEL (used only if the main one fails; you choose it, never automatic)", color = DjColors.TextDim, fontSize = 10.sp)
        DjField(AiSettings.fallback(), { AiSettings.fallbacks[p.name] = it; AiSettings.save() }, "optional")

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonButton("TEST CONNECTION", DjColors.Blue, Modifier.weight(1f), active = busy) {
                run("Testing…") { "Connected ✔  ${AiClient.listModels().size} models available" }
            }
            NeonButton("TEST MODEL", DjColors.Blue, Modifier.weight(1f), active = busy) {
                run("Testing model…") { AiClient.chat("Reply with the single word OK.", "ping", AiSettings.model()); "Model works ✔" }
            }
        }
        NeonButton("FETCH MODELS", DjColors.Purple, Modifier.fillMaxWidth(), active = busy) {
            run("Fetching…") { fetched = AiClient.listModels(); "${fetched.size} models fetched. Tap one below." }
        }
        if (p == Provider.OPENROUTER) {
            NeonButton(if (AiSettings.freeOnly) "SHOWING FREE MODELS ONLY" else "SHOWING ALL (paid ones may cost credits)",
                DjColors.Purple, Modifier.fillMaxWidth(), active = AiSettings.freeOnly) {
                AiSettings.freeOnly = !AiSettings.freeOnly; AiSettings.save()
            }
        }
        if (fetched.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NeonButton("TAP SETS: MODEL", DjColors.Cyan, Modifier.weight(1f), active = target == 0, h = 28.dp) { target = 0 }
                NeonButton("TAP SETS: FALLBACK", DjColors.Cyan, Modifier.weight(1f), active = target == 1, h = 28.dp) { target = 1 }
            }
            val shown = if (p == Provider.OPENROUTER && AiSettings.freeOnly) fetched.filter { it.free } else fetched
            LazyColumn(Modifier.fillMaxWidth().height(180.dp).background(DjColors.Panel)) {
                items(shown) { m ->
                    Text(
                        m.id + if (m.free) "  (free)" else "", color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().clickable {
                            if (target == 0) AiSettings.models[p.name] = m.id else AiSettings.fallbacks[p.name] = m.id
                            AiSettings.save()
                        }.padding(8.dp)
                    )
                }
            }
        }
        if (status.isNotEmpty()) Text(status, color = Color.White, fontSize = 11.sp)
        if (AiClient.lastRate.isNotEmpty()) Text("Rate info: " + AiClient.lastRate, color = DjColors.TextDim, fontSize = 10.sp)

        Row(Modifier.fillMaxWidth().clickable { AiSettings.shareTitles = !AiSettings.shareTitles; AiSettings.save() }) {
            Text((if (AiSettings.shareTitles) "☑" else "☐") + "  Share loaded track names with the AI (off by default)", color = Color.White, fontSize = 11.sp)
        }
        Text(
            "Notes: a key stored in a mobile app can't be fully secret (it is encrypted at rest with Android Keystore, " +
                "but a rooted phone or a modified app could still reach it). A backend proxy can replace this later. " +
                "Nothing here buys credits or switches to paid models by itself. Free tiers have rate limits.",
            color = DjColors.TextDim, fontSize = 9.sp
        )
    }
}
