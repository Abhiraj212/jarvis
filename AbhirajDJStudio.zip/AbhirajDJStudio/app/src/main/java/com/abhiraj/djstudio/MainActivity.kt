package com.abhiraj.djstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.abhiraj.djstudio.ai.AiSettings
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.DjStudioApp
import com.abhiraj.djstudio.ui.theme.DjStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Studio.init(applicationContext)
        AiSettings.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            DjStudioTheme {
                DjStudioApp()
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) Studio.release()
        super.onDestroy()
    }
}
