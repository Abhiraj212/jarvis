package com.abhiraj.djstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Deck
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.Overlay
import com.abhiraj.djstudio.ui.components.JogWheel
import com.abhiraj.djstudio.ui.components.Knob
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.NeonSlider
import com.abhiraj.djstudio.ui.components.WaveformBar
import com.abhiraj.djstudio.ui.components.screenBrush
import com.abhiraj.djstudio.ui.theme.DjColors

private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun MixerScreen(onOpen: (Overlay) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(screenBrush(DjColors.Cyan))
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 6.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("ABHIRAJ DJ STUDIO", color = DjColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            NeonButton("LIB", DjColors.Blue, Modifier.width(44.dp), h = 28.dp) { onOpen(Overlay.LIBRARY) }
            NeonButton("AI", DjColors.Magenta, Modifier.width(40.dp), h = 28.dp) { onOpen(Overlay.AI) }
            NeonButton("⚙", DjColors.Purple, Modifier.width(40.dp), h = 28.dp) { onOpen(Overlay.SETTINGS) }
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DeckPanel(Studio.deckA, Studio.deckB, DjColors.Cyan, Modifier.weight(1f))
            DeckPanel(Studio.deckB, Studio.deckA, DjColors.Magenta, Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("A", color = DjColors.Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                NeonSlider(Studio.crossfader, { Studio.crossfader = it; Studio.applyMix() }, Color.White, h = 28.dp, centerMark = true)
            }
            Spacer(Modifier.width(8.dp))
            Text("B", color = DjColors.Magenta, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Text(
            "swipe ← pads · → FX · ↑ beat maker   |   tap BPM text = reset tempo",
            color = DjColors.TextDim, fontSize = 9.sp, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun DeckPanel(deck: Deck, other: Deck, color: Color, modifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.fillMaxHeight().clip(shape).background(DjColors.Panel).border(1.dp, color.copy(alpha = 0.5f), shape).padding(5.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(deck.name, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.width(5.dp))
            Text(
                deck.msg ?: deck.title,
                color = if (deck.msg != null) DjColors.Magenta else Color.White,
                fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
        }
        Row {
            Text(fmt(deck.positionMs), color = DjColors.TextDim, fontSize = 9.sp, modifier = Modifier.weight(1f))
            Text(fmt(deck.durationMs), color = DjColors.TextDim, fontSize = 9.sp)
        }
        WaveformBar(deck, color, h = 32.dp)
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val s = minOf(maxWidth, maxHeight)
            JogWheel(deck, color, Modifier.size(s))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            NeonButton(if (deck.isPlaying) "❚❚" else "▶", color, Modifier.weight(1f), active = deck.isPlaying) { deck.togglePlay() }
            NeonButton("CUE", color, Modifier.weight(1f)) { deck.cue() }
            NeonButton("SYNC", color, Modifier.weight(1f)) { deck.syncTo(other) }
        }
        val looping = deck.loopStart >= 0 && deck.loopEnd > deck.loopStart
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            NeonButton("IN", color, Modifier.weight(1f), h = 28.dp) { deck.loopIn() }
            NeonButton("OUT", color, Modifier.weight(1f), h = 28.dp, active = looping) { deck.loopOut() }
            NeonButton("1B", color, Modifier.weight(1f), h = 28.dp) { deck.loopBeats(1) }
            NeonButton("4B", color, Modifier.weight(1f), h = 28.dp) { deck.loopBeats(4) }
            NeonButton("✕", color, Modifier.weight(1f), h = 28.dp) { deck.loopExit() }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            val bpmText = if (deck.bpm > 0f) "%.1f".format(deck.bpm * deck.speed) else "--"
            Text(
                "BPM $bpmText  ${"%+.1f".format((deck.speed - 1f) * 100f)}%",
                color = Color.White, fontSize = 10.sp, maxLines = 1,
                modifier = Modifier.weight(1f).clickable { deck.setSpeedValue(1f) }
            )
            NeonButton("TAP", color, Modifier.width(44.dp), h = 26.dp) { deck.tapTempo() }
        }
        NeonSlider(
            (deck.speed - 0.7f) / 0.6f, { deck.setSpeedValue(0.7f + 0.6f * it) },
            color, h = 22.dp, centerMark = true
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob("BASS", deck.bass, { deck.bass = it; deck.applyEq() }, color)
            Knob("MID", deck.mid, { deck.mid = it; deck.applyEq() }, color)
            Knob("TREB", deck.treble, { deck.treble = it; deck.applyEq() }, color)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("VOL", color = DjColors.TextDim, fontSize = 9.sp)
            Spacer(Modifier.width(4.dp))
            NeonSlider(deck.volume, { deck.volume = it; deck.applyVolume() }, color, h = 22.dp)
        }
    }
}
