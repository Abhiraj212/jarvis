package com.abhiraj.djstudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object DjColors {
    val Bg = Color(0xFF07040F)
    val Panel = Color(0xFF120A24)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val Purple = Color(0xFF7C4DFF)
    val Magenta = Color(0xFFFF2DCB)
    val TextDim = Color(0xFF9A8FB8)
}

private val Scheme = darkColorScheme(
    primary = DjColors.Cyan,
    secondary = DjColors.Magenta,
    tertiary = DjColors.Purple,
    background = DjColors.Bg,
    surface = DjColors.Panel,
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun DjStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
