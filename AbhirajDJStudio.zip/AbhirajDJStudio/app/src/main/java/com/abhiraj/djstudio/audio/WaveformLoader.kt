package com.abhiraj.djstudio.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.abs

/** Decodes a track once (background thread) and returns normalized peaks for drawing. */
object WaveformLoader {
    fun compute(ctx: Context, uri: Uri, bars: Int = 300): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            if (!fmt.containsKey(MediaFormat.KEY_DURATION)) return null
            val durUs = fmt.getLong(MediaFormat.KEY_DURATION)
            if (durUs <= 0L) return null
            ex.selectTrack(track)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val peaks = FloatArray(bars)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val deadline = System.currentTimeMillis() + 40_000
            while (!outDone && System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val bin = ((info.presentationTimeUs.toDouble() / durUs) * bars).toInt().coerceIn(0, bars - 1)
                        var mx = 0
                        while (sb.hasRemaining()) { val v = abs(sb.get().toInt()); if (v > mx) mx = v }
                        val pk = mx / 32768f
                        if (pk > peaks[bin]) peaks[bin] = pk
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
            val max = peaks.maxOrNull() ?: 0f
            if (max <= 0f) return null
            return FloatArray(bars) { peaks[it] / max }
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { ex.release() } catch (e: Exception) { }
        }
    }
}
