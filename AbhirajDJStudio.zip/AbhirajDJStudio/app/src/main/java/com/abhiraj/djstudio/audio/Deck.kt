package com.abhiraj.djstudio.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** One DJ deck backed by a MediaPlayer + android.media.audiofx effects. */
class Deck(private val ctx: Context, val name: String) {
    var title by mutableStateOf("— no track —")
    var msg by mutableStateOf<String?>(null)
    var loaded by mutableStateOf(false)
    var isPlaying by mutableStateOf(false)
    var durationMs by mutableIntStateOf(0)
    var positionMs by mutableIntStateOf(0)
    var volume by mutableFloatStateOf(0.8f)
    var speed by mutableFloatStateOf(1f)      // tempo multiplier (pitch is kept)
    var bpm by mutableFloatStateOf(0f)        // ORIGINAL track BPM, 0 = unknown (set with TAP)
    var bass by mutableFloatStateOf(0.5f)     // 0.5 = flat
    var mid by mutableFloatStateOf(0.5f)
    var treble by mutableFloatStateOf(0.5f)
    var loopStart by mutableIntStateOf(-1)
    var loopEnd by mutableIntStateOf(-1)
    var cueMs by mutableIntStateOf(0)
    var fxBass by mutableFloatStateOf(0f)
    var fxVirt by mutableFloatStateOf(0f)
    var fxReverb by mutableFloatStateOf(0f)
    var fxNote by mutableStateOf("")
    var waveform by mutableStateOf<FloatArray?>(null)
    var mixGain = 1f
    private var loadId = 0

    private var mp: MediaPlayer? = null
    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var virt: Virtualizer? = null
    private var msgAt = 0L
    private val taps = ArrayList<Long>()

    private fun say(text: String) { msg = text; msgAt = SystemClock.uptimeMillis() }

    fun load(uri: Uri, displayName: String) {
        releasePlayer()
        title = displayName
        fxNote = ""
        waveform = null
        val myId = ++loadId
        Studio.scope.launch {
            val w = withContext(Dispatchers.IO) { WaveformLoader.compute(ctx, uri) }
            if (myId == loadId) waveform = w
        }
        try {
            val p = MediaPlayer()
            mp = p
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(ctx, uri)
            p.setOnPreparedListener { onPrepared(it) }
            p.setOnCompletionListener { isPlaying = false; positionMs = 0 }
            p.setOnErrorListener { _, _, _ ->
                say("Playback error"); loaded = false; isPlaying = false; true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            say("Cannot open file (permission lost?)")
            try { mp?.release() } catch (x: Exception) { }
            mp = null
        }
    }

    private fun onPrepared(p: MediaPlayer) {
        loaded = true
        durationMs = p.duration
        positionMs = 0
        cueMs = 0
        val sid = p.audioSessionId
        val notes = ArrayList<String>()
        try { eq = Equalizer(0, sid).also { it.setEnabled(true) } } catch (e: Exception) { eq = null; notes.add("EQ") }
        try { bb = BassBoost(0, sid).also { it.setEnabled(true) } } catch (e: Exception) { bb = null; notes.add("Bass boost") }
        try { virt = Virtualizer(0, sid).also { it.setEnabled(true) } } catch (e: Exception) { virt = null; notes.add("Virtualizer") }
        Studio.reverb?.let { try { p.attachAuxEffect(it.id) } catch (e: Exception) { notes.add("Reverb") } }
        if (Studio.reverb == null) notes.add("Reverb")
        fxNote = if (notes.isEmpty()) "" else "Not supported on this phone: " + notes.joinToString(", ")
        applyAll()
    }

    fun applyAll() { applyVolume(); applyEq(); applyFx() }

    fun applyVolume() {
        val v = (volume * mixGain).coerceIn(0f, 1f)
        try { mp?.setVolume(v, v) } catch (e: Exception) { }
    }

    fun applyEq() {
        val e = eq ?: return
        try {
            val range = e.bandLevelRange
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            for (b in 0 until e.numberOfBands.toInt()) {
                val f = e.getCenterFreq(b.toShort())   // milliHertz
                val v = when {
                    f < 300_000 -> bass
                    f < 3_500_000 -> mid
                    else -> treble
                }
                e.setBandLevel(b.toShort(), (lo + (hi - lo) * v).toInt().toShort())
            }
        } catch (x: Exception) { }
    }

    fun applyFx() {
        try { bb?.let { if (it.strengthSupported) it.setStrength((fxBass * 1000).toInt().toShort()) } } catch (e: Exception) { }
        try { virt?.let { if (it.strengthSupported) it.setStrength((fxVirt * 1000).toInt().toShort()) } } catch (e: Exception) { }
        try { mp?.setAuxEffectSendLevel(fxReverb) } catch (e: Exception) { }
    }

    private fun applyTempo() {
        val p = mp ?: return
        try { p.playbackParams = PlaybackParams().setSpeed(speed) } catch (e: Exception) { }
    }

    fun setSpeedValue(s: Float) {
        speed = s.coerceIn(0.7f, 1.3f)
        if (isPlaying) applyTempo()   // applied on next play if paused (avoids auto-start quirk)
    }

    fun togglePlay() {
        val p = mp ?: return
        if (!loaded) return
        try {
            if (p.isPlaying) {
                p.pause(); isPlaying = false
            } else {
                p.start(); isPlaying = true; applyTempo()
            }
        } catch (e: Exception) { say("Playback error") }
    }

    fun seekTo(ms: Int) {
        val p = mp ?: return
        if (!loaded) return
        val t = ms.coerceIn(0, durationMs)
        try { p.seekTo(t.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (e: Exception) { }
        positionMs = t
    }

    fun seekFraction(f: Float) = seekTo((f * durationMs).toInt())

    /** Jog-wheel scratch: moves the playhead (seek based, not true vinyl emulation). */
    fun scratch(deltaDegrees: Float) = seekTo(positionMs + (deltaDegrees * 5f).toInt())

    fun cue() {
        if (!loaded) return
        if (isPlaying) { try { mp?.pause() } catch (e: Exception) { }; isPlaying = false; seekTo(cueMs) }
        else cueMs = positionMs
    }

    fun loopIn() { if (loaded) { loopStart = positionMs; loopEnd = -1 } }
    fun loopOut() { if (loopStart >= 0 && positionMs > loopStart + 100) loopEnd = positionMs }
    fun loopExit() { loopStart = -1; loopEnd = -1 }
    fun loopBeats(beats: Int) {
        if (!loaded) return
        if (bpm <= 0f) { say("Tap BPM first"); return }
        loopStart = positionMs
        loopEnd = (positionMs + beats * 60000f / bpm).toInt().coerceAtMost(durationMs)
    }

    /** Tap in rhythm with the music (works at any tempo setting). */
    fun tapTempo() {
        val now = SystemClock.uptimeMillis()
        if (taps.isNotEmpty() && now - taps.last() > 2000) taps.clear()
        taps.add(now)
        if (taps.size > 6) taps.removeAt(0)
        if (taps.size >= 2) {
            val avg = (taps.last() - taps.first()).toFloat() / (taps.size - 1)
            bpm = (60000f / avg / speed).coerceIn(40f, 220f)
        }
    }

    fun syncTo(other: Deck) {
        if (bpm <= 0f || other.bpm <= 0f) { say("Tap BPM on both decks"); return }
        setSpeedValue(other.bpm * other.speed / bpm)
    }

    fun tick() {
        if (msg != null && SystemClock.uptimeMillis() - msgAt > 3000) msg = null
        val p = mp ?: return
        if (!loaded || !isPlaying) return
        try {
            val pos = p.currentPosition
            if (loopStart >= 0 && loopEnd > loopStart && pos >= loopEnd) seekTo(loopStart) else positionMs = pos
        } catch (e: Exception) { }
    }

    private fun releasePlayer() {
        isPlaying = false; loaded = false
        try { eq?.release() } catch (e: Exception) { }
        try { bb?.release() } catch (e: Exception) { }
        try { virt?.release() } catch (e: Exception) { }
        eq = null; bb = null; virt = null
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        positionMs = 0; durationMs = 0; loopStart = -1; loopEnd = -1
    }

    fun release() = releasePlayer()
}
