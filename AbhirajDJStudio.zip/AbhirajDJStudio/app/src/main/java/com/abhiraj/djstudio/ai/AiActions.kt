package com.abhiraj.djstudio.ai

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.abhiraj.djstudio.audio.Deck
import com.abhiraj.djstudio.audio.Studio
import org.json.JSONArray
import org.json.JSONObject

/** The ONLY things the AI can ask the app to do. Every action is shown and needs the user's tap. */
object AiActions {
    class Action(val label: String, val run: () -> Unit)
    class Parsed(val actions: List<Action>, val ignored: Int)

    private fun deck(s: String): Deck = if (s.trim().uppercase() == "B") Studio.deckB else Studio.deckA
    private fun num(o: JSONObject, k: String, def: Double) = o.optDouble(k, def).toFloat()

    fun parse(arr: JSONArray?): Parsed {
        val out = ArrayList<Action>()
        var ignored = 0
        if (arr == null) return Parsed(out, 0)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o == null) { ignored++; continue }
            try {
                when (o.optString("type")) {
                    "set_eq" -> {
                        val d = deck(o.optString("deck"))
                        val b = num(o, "bass", d.bass.toDouble()).coerceIn(0f, 1f)
                        val m = num(o, "mid", d.mid.toDouble()).coerceIn(0f, 1f)
                        val t = num(o, "treble", d.treble.toDouble()).coerceIn(0f, 1f)
                        out.add(Action("Deck ${d.name} EQ: bass %.2f, mid %.2f, treble %.2f".format(b, m, t)) {
                            d.bass = b; d.mid = m; d.treble = t; d.applyEq()
                        })
                    }
                    "set_tempo" -> {
                        val d = deck(o.optString("deck"))
                        val s = num(o, "speed", 1.0).coerceIn(0.7f, 1.3f)
                        out.add(Action("Deck ${d.name} tempo: %+.1f%%".format((s - 1f) * 100f)) { d.setSpeedValue(s) })
                    }
                    "set_fx" -> {
                        val d = deck(o.optString("deck"))
                        val b = num(o, "bass_boost", d.fxBass.toDouble()).coerceIn(0f, 1f)
                        val v = num(o, "virtualizer", d.fxVirt.toDouble()).coerceIn(0f, 1f)
                        val r = num(o, "reverb", d.fxReverb.toDouble()).coerceIn(0f, 1f)
                        out.add(Action("Deck ${d.name} FX: bass boost %.2f, virtualizer %.2f, reverb %.2f".format(b, v, r)) {
                            d.fxBass = b; d.fxVirt = v; d.fxReverb = r; d.applyFx()
                        })
                    }
                    "set_beat_bpm" -> {
                        val bpm = num(o, "bpm", 120.0).coerceIn(60f, 180f)
                        out.add(Action("Beat Maker BPM: %.0f".format(bpm)) { Studio.seq.bpm = bpm })
                    }
                    "set_pattern" -> {
                        val names = Studio.seq.trackNames
                        val tr = if (o.has("track") && o.opt("track") is Number) o.getInt("track")
                        else names.indexOfFirst { it.equals(o.optString("track"), ignoreCase = true) }
                        val steps = o.optJSONArray("steps")
                        if (tr in 0..5 && steps != null) {
                            val list = List(16) { k -> steps.optInt(k, 0) != 0 }
                            out.add(Action("Beat Maker ${names[tr]}: " + list.joinToString("") { if (it) "x" else "." }) {
                                Studio.seq.setPattern(tr, list)
                            })
                        } else ignored++
                    }
                    else -> ignored++
                }
            } catch (e: Exception) { ignored++ }
        }
        return Parsed(out, ignored)
    }
}

class ChatMsg(val fromUser: Boolean, val text: String, val actions: List<AiActions.Action> = emptyList(), val ignored: Int = 0) {
    var applied by mutableStateOf(false)
}
