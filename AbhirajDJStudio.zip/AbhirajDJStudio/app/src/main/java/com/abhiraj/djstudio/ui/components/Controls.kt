package com.abhiraj.djstudio.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Deck
import com.abhiraj.djstudio.ui.theme.DjColors
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NeonButton(
    text: String, color: Color, modifier: Modifier = Modifier,
    active: Boolean = false, h: Dp = 32.dp, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.height(h).clip(shape)
            .background(if (active) color.copy(alpha = 0.35f) else DjColors.Panel)
            .border(1.dp, color.copy(alpha = if (active) 1f else 0.5f), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (active) Color.White else color, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun NeonSlider(
    value: Float, onChange: (Float) -> Unit, color: Color,
    modifier: Modifier = Modifier, h: Dp = 26.dp, centerMark: Boolean = false
) {
    val cb = rememberUpdatedState(onChange)
    Canvas(
        modifier.fillMaxWidth().height(h).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                down.consume()
                cb.value((down.position.x / size.width).coerceIn(0f, 1f))
                drag(down.id) { c ->
                    cb.value((c.position.x / size.width).coerceIn(0f, 1f)); c.consume()
                }
            }
        }
    ) {
        val cy = size.height / 2f
        val v = value.coerceIn(0f, 1f)
        drawLine(Color(0xFF2A1F45), Offset(0f, cy), Offset(size.width, cy), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
        drawLine(color, Offset(0f, cy), Offset(size.width * v, cy), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        if (centerMark) drawLine(
            Color.White.copy(alpha = 0.5f), Offset(size.width / 2f, cy - 8.dp.toPx()),
            Offset(size.width / 2f, cy + 8.dp.toPx()), strokeWidth = 1.dp.toPx()
        )
        val tw = 12.dp.toPx()
        drawRoundRect(
            Color.White,
            topLeft = Offset((size.width * v - tw / 2f).coerceIn(0f, size.width - tw), cy - 10.dp.toPx()),
            size = Size(tw, 20.dp.toPx()), cornerRadius = CornerRadius(4.dp.toPx())
        )
    }
}

@Composable
fun Knob(label: String, value: Float, onChange: (Float) -> Unit, color: Color, modifier: Modifier = Modifier) {
    val cb = rememberUpdatedState(onChange)
    val v = rememberUpdatedState(value)
    val lastTap = remember { longArrayOf(0L) }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(38.dp).pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    if (down.uptimeMillis - lastTap[0] < 300) cb.value(0.5f)   // double tap = flat
                    lastTap[0] = down.uptimeMillis
                    var lastY = down.position.y
                    drag(down.id) { c ->
                        val dy = c.position.y - lastY
                        lastY = c.position.y
                        cb.value((v.value - dy / 250f).coerceIn(0f, 1f)); c.consume()
                    }
                }
            }
        ) {
            val st = 4.dp.toPx()
            val tl = Offset(st, st)
            val sz = Size(size.width - 2 * st, size.height - 2 * st)
            val vv = value.coerceIn(0f, 1f)
            drawArc(Color(0xFF2A1F45), 135f, 270f, false, topLeft = tl, size = sz, style = Stroke(st, cap = StrokeCap.Round))
            drawArc(color, 135f, 270f * vv, false, topLeft = tl, size = sz, style = Stroke(st, cap = StrokeCap.Round))
            val ang = Math.toRadians((135f + 270f * vv).toDouble())
            val r = size.width / 2f - st * 1.6f
            drawLine(
                Color.White, center,
                Offset(center.x + (r * cos(ang)).toFloat(), center.y + (r * sin(ang)).toFloat()),
                strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round
            )
        }
        Text(label, color = DjColors.TextDim, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
fun JogWheel(deck: Deck, color: Color, modifier: Modifier = Modifier) {
    val dk = rememberUpdatedState(deck)
    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                down.consume()
                val cx = size.width / 2f
                val cy = size.height / 2f
                var last = atan2(down.position.y - cy, down.position.x - cx)
                drag(down.id) { c ->
                    val a = atan2(c.position.y - cy, c.position.x - cx)
                    var d = a - last
                    val pi = PI.toFloat()
                    if (d > pi) d -= 2f * pi
                    if (d < -pi) d += 2f * pi
                    last = a
                    dk.value.scratch(d * 180f / pi)
                    c.consume()
                }
            }
        }
    ) {
        val r = size.minDimension / 2f
        val c = center
        val rot = (deck.positionMs * 0.2f) % 360f     // ~33 rpm look
        drawCircle(color.copy(alpha = 0.25f), radius = r, center = c)
        drawCircle(Color(0xFF0C0818), radius = r * 0.94f, center = c)
        drawCircle(color, radius = r * 0.94f, center = c, style = Stroke(2.dp.toPx()))
        for (k in 1..4) drawCircle(
            Color.White.copy(alpha = 0.06f), radius = r * (0.9f - k * 0.14f), center = c, style = Stroke(1.dp.toPx())
        )
        rotate(rot, pivot = c) {
            drawCircle(color.copy(alpha = 0.9f), radius = r * 0.28f, center = c)
            drawLine(
                Color.White, Offset(c.x, c.y - r * 0.28f), Offset(c.x, c.y - r * 0.9f),
                strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round
            )
            drawCircle(Color(0xFF0C0818), radius = r * 0.06f, center = c)
        }
    }
}

@Composable
fun WaveformBar(deck: Deck, color: Color, modifier: Modifier = Modifier, h: Dp = 34.dp) {
    val dk = rememberUpdatedState(deck)
    Canvas(
        modifier.fillMaxWidth().height(h).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                down.consume()
                dk.value.seekFraction((down.position.x / size.width).coerceIn(0f, 1f))
                drag(down.id) { c ->
                    dk.value.seekFraction((c.position.x / size.width).coerceIn(0f, 1f)); c.consume()
                }
            }
        }
    ) {
        val w = deck.waveform
        val frac = if (deck.durationMs > 0) deck.positionMs.toFloat() / deck.durationMs else 0f
        val mid = size.height / 2f
        if (w != null && w.isNotEmpty()) {
            val n = w.size
            val bw = size.width / n
            for (i in 0 until n) {
                val x = i * bw + bw / 2f
                val a = (w[i] * mid).coerceAtLeast(1f)
                drawLine(
                    if (i.toFloat() / n < frac) color else color.copy(alpha = 0.35f),
                    Offset(x, mid - a), Offset(x, mid + a), strokeWidth = (bw * 0.7f).coerceAtLeast(1f)
                )
            }
        } else {
            drawLine(color.copy(alpha = 0.3f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 2.dp.toPx())
        }
        if (deck.loopStart >= 0 && deck.loopEnd > deck.loopStart && deck.durationMs > 0) {
            drawRect(
                Color.White.copy(alpha = 0.18f),
                topLeft = Offset(size.width * deck.loopStart / deck.durationMs, 0f),
                size = Size(size.width * (deck.loopEnd - deck.loopStart) / deck.durationMs, size.height)
            )
        }
        drawLine(Color.White, Offset(size.width * frac, 0f), Offset(size.width * frac, size.height), strokeWidth = 2.dp.toPx())
    }
}
