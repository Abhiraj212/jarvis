package com.abhiraj.djstudio.audio

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 6 tracks x 16 steps. Always uses the built-in sounds (so live play and WAV export match). */
class Sequencer {
    val trackNames = listOf("KICK", "SNARE", "HAT", "O-HAT", "CLAP", "TOM")
    val grid = mutableStateListOf<Boolean>().apply { repeat(6 * 16) { add(false) } }
    var bpm by mutableFloatStateOf(120f)
    var playing by mutableStateOf(false)
    var step by mutableIntStateOf(-1)
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    init {
        for (s in 0 until 16 step 4) grid[s] = true
        grid[16 + 4] = true; grid[16 + 12] = true
        for (s in 0 until 16 step 2) grid[32 + s] = true
    }

    fun toggle(track: Int, s: Int) { val i = track * 16 + s; grid[i] = !grid[i] }
    fun clear() { for (i in grid.indices) grid[i] = false }
    fun setPattern(track: Int, steps: List<Boolean>) {
        if (track !in 0..5) return
        for (s in 0 until 16) grid[track * 16 + s] = steps.getOrElse(s) { false }
    }

    fun start() {
        if (playing) return
        playing = true
        job = scope.launch {
            var next = SystemClock.uptimeMillis()
            var s = 0
            while (isActive) {
                for (t in 0 until 6) if (grid[t * 16 + s]) Studio.drums.hitBuiltin(t)
                step = s
                next += (60000f / bpm / 4f).toLong()
                delay((next - SystemClock.uptimeMillis()).coerceAtLeast(0))
                s = (s + 1) % 16
            }
        }
    }

    fun stop() { job?.cancel(); job = null; playing = false; step = -1 }

    /** Renders the pattern (4 bars) to a mono 16-bit WAV. */
    suspend fun renderWav(bars: Int = 4): ByteArray = withContext(Dispatchers.Default) {
        val stepSamples = (60.0 / bpm / 4.0 * DrumSynth.SR).toInt()
        val total = stepSamples * 16 * bars
        val mix = FloatArray(total + DrumSynth.SR)
        val pcms = List(6) { DrumSynth.pcm(it) }
        for (b in 0 until bars) for (s in 0 until 16) for (t in 0 until 6) {
            if (grid[t * 16 + s]) {
                val start = (b * 16 + s) * stepSamples
                val p = pcms[t]
                for (i in p.indices) {
                    val idx = start + i
                    if (idx >= mix.size) break
                    mix[idx] += p[i] / 32768f
                }
            }
        }
        val out = ShortArray(mix.size) { (mix[it].coerceIn(-1f, 1f) * 32000f).toInt().toShort() }
        DrumSynth.wavBytes(out)
    }
}
