package com.abhiraj.djstudio.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.NeonSlider
import com.abhiraj.djstudio.ui.components.screenBrush
import com.abhiraj.djstudio.ui.theme.DjColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BeatMakerScreen() {
    val seq = Studio.seq
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("swipe down to go back") }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) scope.launch {
            status = "Rendering…"
            try {
                val bytes = seq.renderWav()
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
                status = "Exported 4 bars (WAV)"
            } catch (e: Exception) { status = "Export failed: ${e.message}" }
        }
    }
    val colors = listOf(DjColors.Cyan, DjColors.Blue, DjColors.Purple, DjColors.Magenta, DjColors.Cyan, DjColors.Blue)

    Column(
        Modifier.fillMaxSize().background(screenBrush(DjColors.Blue))
            .statusBarsPadding().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("BEAT MAKER", color = DjColors.Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(status, color = DjColors.TextDim, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonButton(if (seq.playing) "■ STOP" else "▶ PLAY", DjColors.Cyan, Modifier.weight(1f), active = seq.playing) {
                if (seq.playing) seq.stop() else seq.start()
            }
            NeonButton("CLEAR", DjColors.Purple, Modifier.weight(1f)) { seq.clear() }
            NeonButton("EXPORT", DjColors.Magenta, Modifier.weight(1f)) { export.launch("abhiraj-beat.wav") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("BPM %.0f".format(seq.bpm), color = Color.White, fontSize = 12.sp, modifier = Modifier.width(64.dp))
            NeonSlider((seq.bpm - 60f) / 120f, { seq.bpm = 60f + 120f * it }, DjColors.Blue)
        }
        for (t in 0 until 6) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(seq.trackNames[t], color = colors[t], fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(38.dp), maxLines = 1)
                for (s in 0 until 16) {
                    val on = seq.grid[t * 16 + s]
                    val cur = seq.step == s
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(1.dp).clip(RoundedCornerShape(3.dp))
                            .background(if (on) colors[t] else if (s % 4 == 0) Color(0xFF2A1F45) else DjColors.Panel)
                            .then(if (cur) Modifier.border(1.5.dp, Color.White, RoundedCornerShape(3.dp)) else Modifier)
                            .clickable { seq.toggle(t, s) }
                    )
                }
            }
        }
        Text("Built-in sounds only. EXPORT saves a 4-bar WAV via the file picker.", color = DjColors.TextDim, fontSize = 9.sp)
    }
}
