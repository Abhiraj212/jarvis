package com.abhiraj.djstudio.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** 16 pads on SoundPool (low latency, polyphonic). Custom samples must be short. */
class DrumKit(private val ctx: Context) {
    val names = listOf(
        "KICK", "SNARE", "HAT", "O-HAT", "CLAP", "TOM L", "TOM H", "RIM",
        "BELL", "CRASH", "SHAKE", "BASS", "STAB", "ZAP", "BLIP", "808"
    )
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(16)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build()
    private val builtin = IntArray(16)
    private val padSample = IntArray(16)
    val customName = mutableStateListOf<String?>().apply { repeat(16) { add(null) } }
    var note by mutableStateOf("")

    init {
        for (i in 0 until 16) {
            val f = File(ctx.cacheDir, "pad_$i.wav")
            f.writeBytes(DrumSynth.wavBytes(DrumSynth.pcm(i)))
            builtin[i] = pool.load(f.absolutePath, 1)
            padSample[i] = builtin[i]
        }
    }

    fun hit(pad: Int) { pool.play(padSample[pad], 1f, 1f, 1, 0, 1f) }
    fun hitBuiltin(pad: Int) { pool.play(builtin[pad], 1f, 1f, 1, 0, 1f) }

    fun importSample(pad: Int, uri: Uri, display: String) {
        try {
            val f = File(ctx.cacheDir, "custom_$pad.bin")
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                f.outputStream().use { out -> input.copyTo(out) }
            }
            if (f.length() > 3_000_000) {
                f.delete(); note = "File too big for a pad. Use a short sample (a few seconds)."; return
            }
            padSample[pad] = pool.load(f.absolutePath, 1)
            customName[pad] = display
            note = "Pad ${pad + 1}: $display"
        } catch (e: Exception) {
            note = "Import failed: ${e.message}"
        }
    }

    fun resetAll() {
        for (i in 0 until 16) { padSample[i] = builtin[i]; customName[i] = null }
        note = "All pads reset to built-in sounds"
    }

    fun release() { try { pool.release() } catch (e: Exception) { } }
}
