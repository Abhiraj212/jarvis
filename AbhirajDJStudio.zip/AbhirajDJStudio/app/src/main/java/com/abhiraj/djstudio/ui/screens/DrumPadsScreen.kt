package com.abhiraj.djstudio.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.screenBrush
import com.abhiraj.djstudio.ui.theme.DjColors

private fun displayName(ctx: android.content.Context, uri: android.net.Uri): String {
    try {
        ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "sample"
        }
    } catch (e: Exception) { }
    return "sample"
}

@Composable
fun DrumPadsScreen() {
    val ctx = LocalContext.current
    val kit = Studio.drums
    var importMode by remember { mutableStateOf(false) }
    var pendingPad by remember { mutableIntStateOf(-1) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pendingPad >= 0) kit.importSample(pendingPad, uri, displayName(ctx, uri).substringBeforeLast('.'))
        pendingPad = -1
    }
    val colors = listOf(DjColors.Cyan, DjColors.Blue, DjColors.Purple, DjColors.Magenta)

    Column(
        Modifier.fillMaxSize().background(screenBrush(DjColors.Magenta))
            .statusBarsPadding().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("DRUM PADS", color = DjColors.Magenta, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            NeonButton(if (importMode) "IMPORT: ON" else "IMPORT: OFF", DjColors.Cyan, Modifier.width(110.dp), active = importMode) {
                importMode = !importMode
            }
            NeonButton("RESET", DjColors.Purple, Modifier.width(70.dp)) { kit.resetAll() }
            Text(
                if (importMode) "tap a pad, pick a SHORT sample" else kit.note.ifEmpty { "tap pads to play" },
                color = DjColors.TextDim, fontSize = 10.sp, maxLines = 2
            )
        }
        for (row in 0 until 4) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (col in 0 until 4) {
                    val i = row * 4 + col
                    Pad(
                        label = kit.customName[i] ?: kit.names[i],
                        custom = kit.customName[i] != null,
                        color = colors[row],
                        modifier = Modifier.weight(1f)
                    ) {
                        if (importMode) { pendingPad = i; picker.launch(arrayOf("audio/*")) } else kit.hit(i)
                    }
                }
            }
        }
    }
}

@Composable
private fun Pad(label: String, custom: Boolean, color: androidx.compose.ui.graphics.Color, modifier: Modifier, onDown: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val cb = androidx.compose.runtime.rememberUpdatedState(onDown)
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.fillMaxSize().clip(shape)
            .background(if (pressed) color.copy(alpha = 0.55f) else DjColors.Panel)
            .border(2.dp, if (custom) androidx.compose.ui.graphics.Color.White else color, shape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    cb.value()
                    waitForUpOrCancellation()
                    pressed = false
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = androidx.compose.ui.graphics.Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(2.dp))
    }
}
