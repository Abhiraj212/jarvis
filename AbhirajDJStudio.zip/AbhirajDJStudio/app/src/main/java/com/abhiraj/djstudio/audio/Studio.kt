package com.abhiraj.djstudio.audio

import android.content.Context
import android.media.audiofx.PresetReverb
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** App-wide audio state (kept alive across screens). */
object Studio {
    lateinit var app: Context
        private set
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    var reverb: PresetReverb? = null
        private set
    var crossfader by mutableFloatStateOf(0.5f)

    val deckA: Deck by lazy { Deck(app, "A") }
    val deckB: Deck by lazy { Deck(app, "B") }
    val library: Library by lazy { Library(app) }
    val drums: DrumKit by lazy { DrumKit(app) }
    val seq: Sequencer by lazy { Sequencer() }
    private var started = false

    fun init(ctx: Context) {
        if (started) return
        started = true
        app = ctx.applicationContext
        try {
            reverb = PresetReverb(0, 0).also {
                it.setPreset(PresetReverb.PRESET_LARGEHALL)
                it.setEnabled(true)
            }
        } catch (e: Exception) { reverb = null }
        applyMix()
        scope.launch { while (isActive) { deckA.tick(); deckB.tick(); delay(40) } }
    }

    fun applyMix() {
        deckA.mixGain = minOf(1f, 2f * (1f - crossfader))
        deckB.mixGain = minOf(1f, 2f * crossfader)
        deckA.applyVolume(); deckB.applyVolume()
    }

    fun release() {
        deckA.release(); deckB.release()
        seq.stop()
        drums.release()
    }
}
