package com.abhiraj.djstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Deck
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.components.NeonSlider
import com.abhiraj.djstudio.ui.components.screenBrush
import com.abhiraj.djstudio.ui.theme.DjColors

@Composable
fun FxStudioScreen() {
    Column(
        Modifier.fillMaxSize().background(screenBrush(DjColors.Purple))
            .statusBarsPadding().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("FX STUDIO", color = DjColors.Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Uses Android's built-in audio effects. Load a track first. Some phones don't support every effect; unsupported ones are listed.",
            color = DjColors.TextDim, fontSize = 10.sp
        )
        FxCard(Studio.deckA, DjColors.Cyan)
        FxCard(Studio.deckB, DjColors.Magenta)
    }
}

@Composable
private fun FxCard(deck: Deck, color: Color) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.fillMaxWidth().background(DjColors.Panel, shape).border(1.dp, color.copy(alpha = 0.6f), shape).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("DECK ${deck.name}  ·  ${deck.title}", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
        FxRow("BASS BOOST", deck.fxBass, color) { deck.fxBass = it; deck.applyFx() }
        FxRow("VIRTUALIZER", deck.fxVirt, color) { deck.fxVirt = it; deck.applyFx() }
        FxRow("REVERB", deck.fxReverb, color) { deck.fxReverb = it; deck.applyFx() }
        if (deck.fxNote.isNotEmpty()) Text(deck.fxNote, color = DjColors.Magenta, fontSize = 10.sp)
    }
}

@Composable
private fun FxRow(label: String, value: Float, color: Color, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 10.sp, modifier = Modifier.width(90.dp))
        NeonSlider(value, onChange, color)
    }
}
