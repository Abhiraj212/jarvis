package com.abhiraj.djstudio.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abhiraj.djstudio.audio.Studio
import com.abhiraj.djstudio.ui.components.DjField
import com.abhiraj.djstudio.ui.components.NeonButton
import com.abhiraj.djstudio.ui.components.OverlayHeader
import com.abhiraj.djstudio.ui.theme.DjColors

@Composable
fun LibraryScreen(onBack: () -> Unit) {
    val lib = Studio.library
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) lib.onFolderPicked(uri)
    }
    val list = remember(lib.songs, query, sort) {
        val f = lib.songs.filter { it.name.contains(query, ignoreCase = true) }
        if (sort == 0) f.sortedBy { it.name.lowercase() } else f.sortedByDescending { it.size }
    }

    Column(
        Modifier.fillMaxSize().background(DjColors.Bg).statusBarsPadding().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OverlayHeader("MUSIC LIBRARY", onBack)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonButton("PICK FOLDER", DjColors.Cyan, Modifier.weight(1f)) { picker.launch(null) }
            NeonButton("RESCAN", DjColors.Blue, Modifier.weight(1f)) { lib.rescan() }
        }
        Text(
            (lib.folderName?.let { "Folder: $it  ·  " } ?: "") + lib.status,
            color = DjColors.TextDim, fontSize = 11.sp
        )
        Text("Only the folder you pick is read. The app has no access to the rest of your storage.", color = DjColors.TextDim, fontSize = 9.sp)
        DjField(query, { query = it }, "Search songs")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonButton("A–Z", DjColors.Purple, Modifier.weight(1f), active = sort == 0) { sort = 0 }
            NeonButton("BIGGEST", DjColors.Purple, Modifier.weight(1f), active = sort == 1) { sort = 1 }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(list) { song ->
                Row(
                    Modifier.fillMaxWidth().background(DjColors.Panel).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(song.name.substringBeforeLast('.'), color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("%.1f MB".format(song.size / 1048576.0), color = DjColors.TextDim, fontSize = 9.sp)
                    }
                    NeonButton("A", DjColors.Cyan, Modifier.width(40.dp)) {
                        Studio.deckA.load(song.uri, song.name.substringBeforeLast('.')); lib.status = "Loaded to Deck A"
                    }
                    NeonButton("B", DjColors.Magenta, Modifier.width(40.dp)) {
                        Studio.deckB.load(song.uri, song.name.substringBeforeLast('.')); lib.status = "Loaded to Deck B"
                    }
                }
            }
        }
    }
}
