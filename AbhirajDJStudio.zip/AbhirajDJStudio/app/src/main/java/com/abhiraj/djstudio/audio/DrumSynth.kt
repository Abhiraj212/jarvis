package com.abhiraj.djstudio.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh

/** Tiny built-in drum synth: no sample files needed, no downloads. */
object DrumSynth {
    const val SR = 44100
    private val rnd = java.util.Random(42)
    private fun noise(): Double = rnd.nextDouble() * 2.0 - 1.0
    private fun gen(sec: Double, fn: (Double) -> Double): FloatArray {
        val n = (sec * SR).toInt()
        return FloatArray(n) { fn(it.toDouble() / SR).toFloat() }
    }
    private fun sweep(sec: Double, f0: Double, f1: Double, rate: Double, decay: Double, drive: Double = 1.0): FloatArray {
        var ph = 0.0
        return gen(sec) { t ->
            val f = f1 + (f0 - f1) * exp(-t * rate)
            ph += 2.0 * PI * f / SR
            tanh(sin(ph) * exp(-t * decay) * drive)
        }
    }
    private fun hat(sec: Double, decay: Double, level: Double): FloatArray {
        var prev = 0.0
        return gen(sec) { t -> val n = noise(); val h = n - prev; prev = n; h * exp(-t * decay) * level }
    }

    fun pcm(kind: Int): ShortArray {
        val f: FloatArray = when (kind) {
            0 -> sweep(0.4, 160.0, 45.0, 18.0, 7.0)
            1 -> gen(0.25) { t -> noise() * exp(-t * 22.0) * 0.8 + sin(2.0 * PI * 185.0 * t) * exp(-t * 30.0) * 0.5 }
            2 -> hat(0.08, 60.0, 0.6)
            3 -> hat(0.35, 9.0, 0.5)
            4 -> gen(0.25) { t ->
                val env = if (t < 0.03) exp(-((t % 0.01) * 300.0)) else exp(-(t - 0.03) * 18.0)
                noise() * env * 0.7
            }
            5 -> sweep(0.4, 130.0, 70.0, 12.0, 8.0)
            6 -> sweep(0.35, 230.0, 135.0, 12.0, 9.0)
            7 -> gen(0.1) { t -> sin(2.0 * PI * 1700.0 * t) * exp(-t * 90.0) * 0.6 + noise() * exp(-t * 200.0) * 0.3 }
            8 -> gen(0.5) { t -> (sin(2.0 * PI * 540.0 * t) + sin(2.0 * PI * 810.0 * t)) * 0.35 * exp(-t * 9.0) }
            9 -> hat(1.0, 3.0, 0.5)
            10 -> gen(0.15) { t -> noise() * exp(-t * 25.0) * 0.5 * minOf(1.0, t * 200.0) }
            11 -> gen(0.7) { t -> sin(2.0 * PI * 55.0 * t) * exp(-t * 2.5) }
            12 -> gen(0.5) { t ->
                (sin(2.0 * PI * 261.6 * t) + sin(2.0 * PI * 329.6 * t) + sin(2.0 * PI * 392.0 * t)) * 0.25 * exp(-t * 6.0)
            }
            13 -> sweep(0.4, 2000.0, 100.0, 14.0, 5.0)
            14 -> gen(0.1) { t -> (if (sin(2.0 * PI * 1200.0 * t) > 0) 0.4 else -0.4) * exp(-t * 30.0) }
            else -> sweep(0.9, 160.0, 38.0, 12.0, 2.2, 1.5)
        }
        return ShortArray(f.size) { (f[it].coerceIn(-1f, 1f) * 32000f).toInt().toShort() }
    }

    fun wavBytes(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1.toShort()); bb.putShort(1.toShort())
        bb.putInt(SR); bb.putInt(SR * 2); bb.putShort(2.toShort()); bb.putShort(16.toShort())
        bb.put("data".toByteArray()); bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }
}
