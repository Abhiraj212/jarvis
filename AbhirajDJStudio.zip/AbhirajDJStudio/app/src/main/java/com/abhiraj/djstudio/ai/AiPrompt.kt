package com.abhiraj.djstudio.ai

import androidx.compose.runtime.mutableStateListOf
import com.abhiraj.djstudio.audio.Studio
import org.json.JSONObject

object AiChat { val msgs = mutableStateListOf<ChatMsg>() }

object AiPrompt {
    val system = """
You are the DJ assistant inside the Android app "Abhiraj DJ Studio". Be short and practical.
You can suggest BPM and music styles, EQ, FX, drum patterns, remix ideas, and explain the controls.
Controls: two decks (A, B) with play, cue, tempo slider, tap-BPM, sync, loops, 3-band EQ (bass/mid/treble, 0..1 with 0.5 = flat),
FX (bass_boost, virtualizer, reverb, 0..1), crossfader, 16 drum pads, 16-step beat maker with tracks KICK, SNARE, HAT, O-HAT, CLAP, TOM.
You cannot hear the audio and you cannot press anything. You may only PROPOSE these actions; the user must tap Apply:
- {"type":"set_eq","deck":"A|B","bass":0-1,"mid":0-1,"treble":0-1}
- {"type":"set_tempo","deck":"A|B","speed":0.7-1.3}
- {"type":"set_fx","deck":"A|B","bass_boost":0-1,"virtualizer":0-1,"reverb":0-1}
- {"type":"set_beat_bpm","bpm":60-180}
- {"type":"set_pattern","track":"KICK|SNARE|HAT|O-HAT|CLAP|TOM","steps":[16 numbers, 1=hit 0=rest]}
Reply with ONLY one JSON object: {"reply":"your short text","actions":[...]} . Use an empty actions list if none fit.
Never claim an action was applied. Do not invent other action types.
""".trimIndent()

    fun userMessage(text: String): String {
        val a = Studio.deckA
        val b = Studio.deckB
        val sb = StringBuilder("Current settings (no audio is shared):\n")
        for (d in listOf(a, b)) {
            sb.append("Deck ${d.name}: tempo %.2fx, bpm ${if (d.bpm > 0) "%.0f".format(d.bpm) else "unknown"}, ".format(d.speed))
            sb.append("eq %.2f/%.2f/%.2f".format(d.bass, d.mid, d.treble))
            if (AiSettings.shareTitles && d.loaded) sb.append(", track \"${d.title}\"")
            sb.append("\n")
        }
        sb.append("Beat maker bpm: %.0f\n\nUser: ".format(Studio.seq.bpm)).append(text)
        return sb.toString()
    }

    class Reply(val text: String, val actions: List<AiActions.Action>, val ignored: Int)

    fun parseReply(raw: String): Reply {
        val s = raw.trim()
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                val j = JSONObject(s.substring(a, b + 1))
                val p = AiActions.parse(j.optJSONArray("actions"))
                return Reply(j.optString("reply", s), p.actions, p.ignored)
            } catch (e: Exception) { }
        }
        return Reply(s, emptyList(), 0)
    }
}
