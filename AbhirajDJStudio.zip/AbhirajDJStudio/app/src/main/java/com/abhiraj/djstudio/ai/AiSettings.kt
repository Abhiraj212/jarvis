package com.abhiraj.djstudio.ai

import android.content.Context
import com.abhiraj.djstudio.audio.Studio
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Provider(val label: String, val baseUrl: String) {
    GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta"),
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1"),
    CUSTOM("Custom", "")
}

/** Non-secret AI settings live in SharedPreferences; API keys go through SecureStore. */
object AiSettings {
    private var prefs: android.content.SharedPreferences? = null
    var provider by mutableStateOf(Provider.GEMINI)
    var customBase by mutableStateOf("")
    var freeOnly by mutableStateOf(true)
    var shareTitles by mutableStateOf(false)
    var privacyAccepted by mutableStateOf(false)
    var hasKey by mutableStateOf(false)
    val models = mutableStateMapOf<String, String>()
    val fallbacks = mutableStateMapOf<String, String>()

    val keyRequired: Boolean get() = provider != Provider.CUSTOM
    fun model(): String = models[provider.name] ?: ""
    fun fallback(): String = fallbacks[provider.name] ?: ""

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("ai_prefs", Context.MODE_PRIVATE)
        prefs = p
        provider = Provider.values().firstOrNull { it.name == p.getString("provider", null) } ?: Provider.GEMINI
        customBase = p.getString("customBase", "") ?: ""
        freeOnly = p.getBoolean("freeOnly", true)
        shareTitles = p.getBoolean("shareTitles", false)
        privacyAccepted = p.getBoolean("privacy", false)
        for (pr in Provider.values()) {
            p.getString("model_" + pr.name, null)?.let { models[pr.name] = it }
            p.getString("fb_" + pr.name, null)?.let { fallbacks[pr.name] = it }
        }
        refreshKey()
    }

    fun save() {
        val e = prefs?.edit() ?: return
        e.putString("provider", provider.name)
        e.putString("customBase", customBase)
        e.putBoolean("freeOnly", freeOnly)
        e.putBoolean("shareTitles", shareTitles)
        e.putBoolean("privacy", privacyAccepted)
        for ((k, v) in models) e.putString("model_$k", v)
        for ((k, v) in fallbacks) e.putString("fb_$k", v)
        e.apply()
    }

    fun refreshKey() { hasKey = SecureStore.get(Studio.app, "key_" + provider.name) != null }
    fun setKey(v: String) { SecureStore.put(Studio.app, "key_" + provider.name, v.trim()); refreshKey() }
    fun removeKey() { SecureStore.remove(Studio.app, "key_" + provider.name); refreshKey() }
    fun key(): String = SecureStore.get(Studio.app, "key_" + provider.name) ?: ""
}
