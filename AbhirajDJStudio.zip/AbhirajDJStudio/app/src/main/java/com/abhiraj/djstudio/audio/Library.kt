package com.abhiraj.djstudio.audio

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Song(val name: String, val uri: Uri, val size: Long)

/** Music library through the Storage Access Framework: only folders the user picked. */
class Library(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)
    var songs by mutableStateOf<List<Song>>(emptyList())
    var status by mutableStateOf("No folder selected")
    var folderName by mutableStateOf<String?>(null)
    var scanning by mutableStateOf(false)
    private var tree: Uri? = null
    private val exts = setOf("mp3", "wav", "ogg", "m4a", "aac", "flac", "opus")

    init {
        prefs.getString("tree", null)?.let { restore(Uri.parse(it)) }
    }

    private fun hasPermission(uri: Uri) =
        ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }

    private fun restore(uri: Uri) {
        if (hasPermission(uri)) {
            tree = uri
            folderName = uri.lastPathSegment
            scan(uri)
        } else {
            status = "Folder permission was revoked. Pick the folder again."
            prefs.edit().remove("tree").apply()
        }
    }

    fun onFolderPicked(uri: Uri) {
        var persisted = true
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { persisted = false }
        prefs.edit().putString("tree", uri.toString()).apply()
        tree = uri
        folderName = uri.lastPathSegment
        scan(uri)
        if (!persisted) status = "Access may not persist after restart on this phone."
    }

    fun rescan() { tree?.let { scan(it) } }

    private fun scan(uri: Uri) {
        scanning = true
        status = "Scanning…"
        Studio.scope.launch {
            val out = ArrayList<Song>()
            var err: String? = null
            withContext(Dispatchers.IO) {
                try {
                    walk(uri, DocumentsContract.getTreeDocumentId(uri), out, 0)
                } catch (e: SecurityException) {
                    err = "Permission lost. Pick the folder again."
                } catch (e: Exception) {
                    err = "Scan failed: ${e.message}"
                }
            }
            songs = out
            scanning = false
            status = err ?: "${out.size} songs found"
        }
    }

    private fun walk(treeUri: Uri, docId: String, out: MutableList<Song>, depth: Int) {
        if (depth > 8 || out.size > 5000) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                val size = if (c.isNull(3)) 0L else c.getLong(3)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(treeUri, id, out, depth + 1)
                } else if (mime.startsWith("audio/") || exts.contains(name.substringAfterLast('.', "").lowercase())) {
                    out.add(Song(name, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), size))
                }
            }
        }
    }
}
