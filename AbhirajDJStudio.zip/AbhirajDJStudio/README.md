# Abhiraj DJ Studio

Android DJ mixer (Kotlin + Jetpack Compose). Stages 2-6 + waveform are written; NOT yet compiled by the author.

## Build the APK (Android Studio)
1. Open the folder in Android Studio (it creates the Gradle wrapper and downloads dependencies).
2. Wait for "Gradle sync" to finish. Fix/paste any error.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk

## Navigation
Mixer (centre) | swipe left: Drum Pads | swipe right: FX Studio | swipe up: Beat Maker.
LIB = music library, AI = assistant, gear = AI settings.

## Security
No API keys in the source. Keys are entered in the app and stored encrypted with Android Keystore.
secrets.properties / .env are git-ignored.
